import React from 'react'

const page = () => {
  return (
    <div>
      <h1 className='text-xl font-bold text-center pt-9 text-red-500'>This page is not available at the moments</h1>
    </div>
  )
}

export default page
