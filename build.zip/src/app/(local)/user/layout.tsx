"use client";
import "@/app/globals.css";
import { useUser } from "@/context/UserContext";
import { useEffect, useState } from "react";
import Navbar from "@/components/Shared/UserNavbar/Navbar";
import UserSidePanel from "@/components/User/UserSidePanel";
import { Geist_Mono } from "next/font/google";
import { useRouter } from "next/navigation";
import Spinner from "@/components/Shared/Spinner/Spinner";
import { useSetting } from "@/context/SettingContext";
import MaintenancePage from "@/components/MaintenancePage/MaintenancePage";
import InActivePage from "@/components/InActivePage/InActivePage";
import IsPaidPage from "@/components/IsPaidPage/IsPaidPage";

const geistMono = Geist_Mono({
	variable: "--font-geist-mono",
	subsets: ["latin"],
});

export default function UserRootLayout({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	const { setting } = useSetting();
	const { user, loading } = useUser();
	const [isSidePanelOpen, setIsSidePanelOpen] = useState(false);
	const router = useRouter();

	useEffect(() => {
		if (!loading) {
			if (!user?.email || user?.role !== "user") {
				router.push("/login");
			}
		}
	}, [user, loading, router]);

	if (loading || !user?.email || user?.role !== "user") {
		return <Spinner />;
	}

	if (setting?.maintenanceMode === true) {
		return <MaintenancePage />;
	}
	// if user not paid
	if (!user?.isPaid) {
		return <IsPaidPage />;
	}

	// if user in-active
	if (user?.status === "in-active") {
		return <InActivePage />;
	}
	return (
		<div className={`${geistMono.variable} antialiased`}>
			<title>
				User Dashboard | {setting?.siteName || "TelentScopeMarketing"}
			</title>

			<meta
				name="description"
				content={
					setting?.siteName || "Default description for TelentScopeMarketing"
				}
			/>
			<Navbar
				setIsSidePanelOpen={setIsSidePanelOpen}
				isSidePanelOpen={isSidePanelOpen}
			/>
			<main className={`h-screen overflow-y-hidden flex w-full`}>
				<UserSidePanel
					isSidePanelOpen={isSidePanelOpen}
					setIsSidePanelOpen={setIsSidePanelOpen}
				/>
				<div
					className={`relative w-full h-full overflow-auto bg-white pt-[90px] text-black `}
					style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}>
					{children}
				</div>
			</main>
		</div>
	);
}
